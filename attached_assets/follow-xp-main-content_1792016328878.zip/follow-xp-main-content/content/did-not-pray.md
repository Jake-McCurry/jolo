# You do not have to decide today.

You watched. You did not pray. That is an honest answer, and it is all right to still be unsure.

Jesus does not ask you to pretend. If you have a question, start there. If you want to look again at who He is, that door is open.

## Common Next Steps

- [I have questions about what I heard](/more-no-decision-i-have-questions-about-what-i-heard)

- [I’d like to understand the Christian message more clearly](/more-no-decision-id-like-to-understand-the-christian-message-more-clearly)

- [I already follow Jesus and want to go deeper](/more-no-decision-i-already-follow-jesus-and-want-to-go-deeper)

- [I want to help someone else explore these things](/more-no-decision-i-want-to-help-someone-else-explore-these-things)

- [More options?](/more-no-decision-more-options)

## We’re here to answer your questions.

If something is on your mind or you would simply like help finding the right resource, feel free to reach out.

[Send a Message](/message)
